/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.controller;

import bean.dao.profileDB;
import bean.model.Session;
import bean.model.profileData;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SYAH
 */
public class adm_updateProfile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            //retrieve data from jsp
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            String ic = request.getParameter("ic");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String lect_id = request.getParameter("lect_id");

            //insert data into profile class
            profileData prof = new profileData(id, name, ic, phone, email, lect_id);
            
            //create dao object for project class
            profileDB profDB = new profileDB();

            //retrieve role to determine type of user (admin, lecturer, student) for sql query database purposes
            String role = request.getParameter("role");

            //role is student
            if (role.equals("student")) {

                //run sql and return validity
                String admValidate = profDB.admUpdProfileStu(prof);

                //if sql is successful or error
                if (admValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", admValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_stu");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", admValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_stu");
                    rd.forward(request, response);
                }
            }//role is lecturer 
            else if (role.equals("lecturer")) {

                //run sql and return validity
                String admValidate = profDB.admUpdProfileLect(prof);

                //if sql is successful or error
                if (admValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", admValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_lect");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", admValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_lect");
                    rd.forward(request, response);
                }
            }//role does not exist or null, hence user is undermined 
            else {
                RequestDispatcher rd = request.getRequestDispatcher("/logourServlet");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
