/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.controller;

import bean.dao.registerDB;
import bean.model.Session;
import bean.model.registerData;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SYAH
 */
public class registerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String id = request.getParameter("id");
            
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String ic = request.getParameter("ic");
            String email = request.getParameter("email");
            String admin_id = request.getParameter("creator_id");
            
            //PASSWORD = IC NUMBER BY DEFAULT
            //USER NEED TO CHANGE WHEN THEY LOGIN
            String pass = ic;
            
            //Create date using java.util.date
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            String date_created = formatter.format(date);

            //retrieve role to determine type of user (admin, lecturer, student) for sql query database purposes
            String reg = request.getParameter("reg");
            String regValidate = "";
            
            //role is lecturer
            if (reg.equals("lecturer")) {
                
                //insert data into register class
                registerData regD = new registerData(id, pass, name, phone, ic, email, admin_id, null, date_created);
                
                //create dao object for register class
                registerDB regDB = new registerDB();

                //run sql and return validity
                regValidate = regDB.autheticateUserLecturer(regD);

                //if sql is successful or error
                if (regValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", regValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_reg_lect");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", regValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_reg_lect");
                    rd.forward(request, response);
                }
            } else if (reg.equals("student")) {
                //get lecturer id for sql query
                String lect_id = request.getParameter("lect_id");
                
                //insert data into register class
                registerData regD = new registerData(id, pass, name, phone, ic, email, admin_id, lect_id, date_created);
                
                //create dao object for register class
                registerDB regDB = new registerDB();

                //run sql and return validty
                regValidate = regDB.autheticateUserStudent(regD);

                //if sql is successful or error
                if (regValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", regValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_reg_stu");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", regValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_reg_stu");
                    rd.forward(request, response);
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
