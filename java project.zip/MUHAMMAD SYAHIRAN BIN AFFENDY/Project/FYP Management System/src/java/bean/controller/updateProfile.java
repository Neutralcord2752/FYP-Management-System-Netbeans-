/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.controller;

import bean.dao.profileDB;
import bean.model.Session;
import bean.model.profileData;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author SYAH
 */
public class updateProfile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            //retrieve data from jsp
            String id = request.getParameter("id");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String pass = request.getParameter("old_pass");
            String n_pass = request.getParameter("new_pass");
            String c_pass = request.getParameter("confirm_pass");

            //retrieve role to determine type of user (admin, lecturer, student) for sql query database purposes
            HttpSession session1 = request.getSession(false);
            String role = (String) session1.getAttribute("role");

            //insert data into profile object
            profileData prof = new profileData(id, pass, phone, email);

            //create dao object for profile class
            profileDB profDB = new profileDB();
            String profileValidate = null;

            //role is admin
            if (role.equals("admin")) {
                
                //check if new pass = confirm pass
            if (n_pass.length() > 0 && c_pass.length() > 0) {

                //send error message where new pass != confirm pass
                if (!n_pass.equals(c_pass)) {

                    request.setAttribute("passErrMessage", "<font color='red'>New password and confirm password do not match!</font>");
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_profile");
                    rd.forward(request, response);

                } //send error message where new pass != confirm pass
                else {
                    pass = n_pass;
                }
            }
                
                //run sql and return validity
                profileValidate = profDB.updProfileAdmin(prof);

                //if sql is successful or error
                if (profileValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_profile");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/adm_upd_profile");
                    rd.forward(request, response);
                }
            } //role is lecturer
            else if (role.equals("lecturer")) {
                
                //check if new pass = confirm pass
            if (n_pass.length() > 0 && c_pass.length() > 0) {

                //send error message where new pass != confirm pass
                if (!n_pass.equals(c_pass)) {

                    request.setAttribute("passErrMessage", "<font color='red'>New password and confirm password do not match!</font>");
                    RequestDispatcher rd = request.getRequestDispatcher("/lect_upd_profile");
                    rd.forward(request, response);

                } //send error message where new pass != confirm pass
                else {
                    pass = n_pass;
                }
            }

                //run sql and return validity
                profileValidate = profDB.updProfileLect(prof);

                //if sql is successful or error
                if (profileValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/lect_upd_profile");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/lect_upd_profile");
                    rd.forward(request, response);
                }

            }//role is student 
            else if (role.equals("student")) {
                
                //check if new pass = confirm pass
            if (n_pass.length() > 0 && c_pass.length() > 0) {

                //send error message where new pass != confirm pass
                if (!n_pass.equals(c_pass)) {

                    request.setAttribute("passErrMessage", "<font color='red'>New password and confirm password do not match!</font>");
                    RequestDispatcher rd = request.getRequestDispatcher("/stu_upd_profile");
                    rd.forward(request, response);

                } //send error message where new pass != confirm pass
                else {
                    pass = n_pass;
                }
            }
                
                //run sql and return validity
                profileValidate = profDB.updProfileStudent(prof);

                //if sql is successful or error
                if (profileValidate.equals("SUCCESS")) {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/stu_upd_profile");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("errMessage", profileValidate);
                    RequestDispatcher rd = request.getRequestDispatcher("/stu_upd_profile");
                    rd.forward(request, response);
                }
                
            }//role does not exist or null, hence user is undermined
            else {
                RequestDispatcher rd = request.getRequestDispatcher("/logourServlet");
                rd.forward(request, response);
            }
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
