/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.dao;

import bean.model.profileData;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author SYAH
 */
public class profileDB {

    //student - update profile
    public String updProfileStudent(profileData prof) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = prof.getId();
            String pass = prof.getPass();
            String phone = prof.getPhone();
            String email = prof.getEmail();

            String sql = "UPDATE STUDENT SET STU_PASS=?, STU_PHONE=?, STU_EMAIL=? WHERE STU_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, pass);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    //admin - update profile
    public String updProfileAdmin(profileData prof) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = prof.getId();
            String pass = prof.getPass();
            String phone = prof.getPhone();
            String email = prof.getEmail();

            String sql = "UPDATE ADMIN SET ADMIN_PASS=?, ADMIN_PHONE=?, ADMIN_EMAIL=? WHERE ADMIN_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, pass);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    //lecturer - update profile
    public String updProfileLect(profileData prof) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = prof.getId();
            String pass = prof.getPass();
            String phone = prof.getPhone();
            String email = prof.getEmail();

            String sql = "UPDATE LECTURER SET LECT_PASS=?, LECT_PHONE=?, LECT_EMAIL=? WHERE LECT_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, pass);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    public String admUpdProfileStu(profileData prof) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = prof.getId();
            String name = prof.getName();
            String ic = prof.getIc();
            String phone = prof.getPhone();
            String email = prof.getEmail();
            String lect_id = prof.getLect_id();

            String sql = "UPDATE STUDENT SET STU_NAME=?, STU_IC=?, STU_PHONE=?, STU_EMAIL=?, LECT_ID=? WHERE STU_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, name);
            pstmt.setString(2, ic);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.setString(5, lect_id);
            pstmt.setString(6, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    public String admUpdProfileLect(profileData prof) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = prof.getId();
            String name = prof.getName();
            String ic = prof.getIc();
            String phone = prof.getPhone();
            String email = prof.getEmail();

            String sql = "UPDATE LECTURER SET LECT_NAME=?, LECT_IC=?, LECT_PHONE=?, LECT_EMAIL=? WHERE LECT_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, name);
            pstmt.setString(2, ic);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.setString(5, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    public String deleteStudent(profileData prof) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String id = prof.getId();
            String sql = "DELETE FROM STUDENT WHERE STU_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    public String deleteLecturer(profileData prof) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String id = prof.getId();
            String sql = "DELETE FROM LECTURER WHERE LECT_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
}
