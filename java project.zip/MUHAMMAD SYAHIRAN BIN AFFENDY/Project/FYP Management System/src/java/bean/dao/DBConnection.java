/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author SYAH
 */
public class DBConnection {
    
    //create database connection
    public static Connection createConnection(){
        Connection conn;
        try {
            //declare driver and connection string
            String driver = "org.apache.derby.jdbc.ClientDriver";
            String connectionString = "jdbc:derby://localhost:1527/FYP;create=true;user=app;password=app";
            
            //load driver
            Class.forName(driver);

            //Return connection to database
            return DriverManager.getConnection(connectionString);
            
        } catch (Exception ex) {
            ex.getMessage();
        }
        return null;
    }
}
