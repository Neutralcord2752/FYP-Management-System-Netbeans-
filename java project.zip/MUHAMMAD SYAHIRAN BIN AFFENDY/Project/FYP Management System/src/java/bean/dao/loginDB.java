/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.dao;

import bean.model.loginData;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author SYAH
 */
public class loginDB {
    
    //student - authenticate
    public String authenticateUserStudent (loginData ld){
        String username = ld.getUser(); //Assign user entered values to temp
        String password = ld.getPass();
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        String userNameDB = "";
        String passwordDB = "";
        
        try{
            conn = DBConnection.createConnection(); //Fetch Database connection
            st = conn.createStatement(); //statement to write queries
            rs = st.executeQuery("SELECT STU_ID,STU_PASS FROM STUDENT");
            
            while(rs.next()){
                userNameDB = rs.getString("STU_ID"); //get value from database
                passwordDB = rs.getString("STU_PASS");
                
                if(username.equals(userNameDB) && password.equals(passwordDB))
                    return "SUCCESS";
            }
        }catch (SQLException ex){
            return ex.getMessage();
        }
        return "Invalid user credentials";
    }
    
    //lecturer - authenticate
    public String authenticateUserLecturer (loginData ld){
        String username = ld.getUser(); //Assign user entered values to temp
        String password = ld.getPass();
        String err = null;
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        String userNameDB = "";
        String passwordDB = "";
        
        try{
            conn = DBConnection.createConnection(); //Fetch Database connection
            st = conn.createStatement(); //statement to write queries
            rs = st.executeQuery("SELECT LECT_ID,LECT_PASS FROM LECTURER");
            
            while(rs.next()){
                userNameDB = rs.getString("LECT_ID"); //get value from database
                passwordDB = rs.getString("LECT_PASS");
                
                if(username.equals(userNameDB) && password.equals(passwordDB))
                    return "SUCCESS";
            }
        }catch (SQLException ex){
            return ex.getMessage();
        }
        return "Invalid user credentials";
    }
    
    //admin - authenticate
     public String authenticateUserAdmin (loginData ld){
        String username = ld.getUser(); //Assign user entered values to temp
        String password = ld.getPass();
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        String userNameDB = "";
        String passwordDB = "";
        
        try{
            conn = DBConnection.createConnection(); //Fetch Database connection
            st = conn.createStatement(); //statement to write queries
            rs = st.executeQuery("SELECT ADMIN_ID,ADMIN_PASS FROM ADMIN");
            
            while(rs.next()){
                userNameDB = rs.getString("ADMIN_ID"); //get value from database
                passwordDB = rs.getString("ADMIN_PASS");
                
                if(username.equals(userNameDB) && password.equals(passwordDB))
                    return "SUCCESS";
            }
        }catch (SQLException ex){
            return ex.getMessage();
        }
        return "Invalid user credentials";
    }
}
