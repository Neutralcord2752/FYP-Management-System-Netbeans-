/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.dao;

import bean.model.projectData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author SYAH
 */
public class projectDB {

    //student - add project
    public String addProj(projectData proj) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String title = proj.getTitle();
            String desc = proj.getDesc();
            String progress = proj.getProgress();
            String scope = proj.getScope();
            String status = proj.getStatus();
            String link = proj.getLink();
            String stu_id = proj.getStu_id();



            String sql = "INSERT INTO PROJECT (PROJ_TITLE, PROJ_DESC, PROJ_SCOPE, PROJ_LINK, PROJ_PROGRESS, PROJ_STATUS, STU_ID) VALUES (?,?,?,?,?,?,?)";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, title);
            pstmt.setString(2, desc);
            pstmt.setString(3, scope);
            pstmt.setString(4, link);
            pstmt.setString(5, progress);
            pstmt.setString(6, status);
            pstmt.setString(7, stu_id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }

//    private String getLectId(String stu_id) {
//        Connection conn = null;
//        Statement st = null;
//        ResultSet rs = null;
//        String lect_id = null;
//
//        try {
//            conn = DBConnection.createConnection(); //Fetch Database connection
//            st = conn.createStatement(); //statement to write queries
//            rs = st.executeQuery("SELECT LECT_ID FROM STUDENT WHERE STU_ID='" + stu_id + "'");
//
//            while (rs.next()) {
//                lect_id = rs.getString(1); //get value from database
//
//                if (lect_id != null) {
//                    break;
//                }
//            }
//            return lect_id;
//
//        } catch (SQLException ex) {
//            return ex.getMessage();
//        }
//    }
    
    //student - update project
    public String updProj(projectData proj) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String title = proj.getTitle();
            String desc = proj.getDesc();
            String progress = proj.getProgress();
            String scope = proj.getScope();
            String link = proj.getLink();
            int proj_id = proj.getId();

            String sql = "UPDATE PROJECT SET PROJ_TITLE=?,PROJ_DESC=?, PROJ_SCOPE=?, PROJ_LINK=?, PROJ_PROGRESS=? WHERE PROJ_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, title);
            pstmt.setString(2, desc);
            pstmt.setString(3, scope);
            pstmt.setString(4, link);
            pstmt.setString(5, progress);
            pstmt.setInt(6, proj_id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    //lecturer - approve/reject project
    public String approvalProj(projectData proj) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            
            String status = proj.getStatus();
            int proj_id = proj.getId();

            String sql = "UPDATE PROJECT SET PROJ_STATUS=? WHERE PROJ_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, status);
            pstmt.setInt(2, proj_id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    //student - delete project
    public String deleteProj(projectData proj) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            int proj_id = proj.getId();

            String sql = "DELETE FROM PROJECT WHERE PROJ_ID=?";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setInt(1, proj_id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
}
