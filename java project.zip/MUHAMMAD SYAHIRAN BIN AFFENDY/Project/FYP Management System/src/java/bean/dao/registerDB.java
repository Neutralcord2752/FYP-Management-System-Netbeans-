/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.dao;

import bean.model.registerData;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

/**
 *
 * @author SYAH
 */
public class registerDB {

    //admin - register lecturer
    public String autheticateUserLecturer(registerData reg) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = reg.getId();
            String password = reg.getPassword();
            String name = reg.getName();
            String phone = reg.getPhone();
            String ic = reg.getIc();
            String email = reg.getEmail();
            String admin_id = reg.getAdmin_id();

            String dateRetrieved = reg.getDate();
            Date date=Date.valueOf(dateRetrieved);

            String sql = "INSERT INTO LECTURER (LECT_ID, LECT_PASS, LECT_NAME, LECT_PHONE, LECT_IC, LECT_EMAIL, ADMIN_ID, DATE_CREATED) VALUES (?,?,?,?,?,?,?,?)";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, id);
            pstmt.setString(2, password);
            pstmt.setString(3, name);
            pstmt.setString(4, phone);
            pstmt.setString(5, ic);
            pstmt.setString(6, email);
            pstmt.setString(7, admin_id);
            pstmt.setDate(8, date);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    
    //admin - register student
    public String autheticateUserStudent(registerData reg) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            String id = reg.getId();
            String password = reg.getPassword();
            String name = reg.getName();
            String phone = reg.getPhone();
            String ic = reg.getIc();
            String email = reg.getEmail();
            String admin_id = reg.getAdmin_id();
            String lect_id = reg.getLect_id();

            String dateRetrieved = reg.getDate();
            Date date=Date.valueOf(dateRetrieved);

            String sql = "INSERT INTO STUDENT (STU_ID, STU_PASS, STU_NAME, STU_PHONE, STU_IC, STU_EMAIL, ADMIN_ID, DATE_CREATED, LECT_ID) VALUES (?,?,?,?,?,?,?,?,?)";
            conn = DBConnection.createConnection(); //Fetch Database connection
            pstmt = conn.prepareStatement(sql); //statement to write queries

            pstmt.setString(1, id);
            pstmt.setString(2, password);
            pstmt.setString(3, name);
            pstmt.setString(4, phone);
            pstmt.setString(5, ic);
            pstmt.setString(6, email);
            pstmt.setString(7, admin_id);
            pstmt.setDate(8, date);
            pstmt.setString(9, lect_id);
            pstmt.executeUpdate();

            return "SUCCESS";
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
}
