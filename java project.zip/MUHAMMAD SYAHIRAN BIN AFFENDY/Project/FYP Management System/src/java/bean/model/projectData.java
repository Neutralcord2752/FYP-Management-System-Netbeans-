/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.model;

/**
 *
 * @author SYAH
 */
public class projectData {
    private String title,desc, scope, link, status, progress, stu_id, lect_id;
    private int id;

    public projectData() {
    }

    public projectData(String title, String desc, String scope, String link, String status, String progress, String stu_id) {
        this.title = title;
        this.desc = desc;
        this.scope = scope;
        this.link = link;
        this.status = status;
        this.progress = progress;
        this.stu_id = stu_id;
    }

    public projectData(String title, String desc, String scope, String link, String progress, String stu_id, int id) {
        this.title = title;
        this.desc = desc;
        this.scope = scope;
        this.link = link;
        this.progress = progress;
        this.stu_id = stu_id;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getStu_id() {
        return stu_id;
    }

    public void setStu_id(String stu_id) {
        this.stu_id = stu_id;
    }

    public String getLect_id() {
        return lect_id;
    }

    public void setLect_id(String lect_id) {
        this.lect_id = lect_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   
}
