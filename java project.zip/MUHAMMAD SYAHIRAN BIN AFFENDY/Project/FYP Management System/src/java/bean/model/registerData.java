/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.model;

import java.util.Date;

/**
 *
 * @author SYAH
 */
public class registerData {
    private String id, password, name, phone, ic, email, admin_id, lect_id, date;
    
    public registerData() {
    }

    public registerData(String id, String password, String name, String phone, String ic, String email, String admin_id, String lect_id, String date) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.ic = ic;
        this.email = email;
        this.admin_id = admin_id;
        this.lect_id = lect_id;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIc() {
        return ic;
    }

    public void setIc(String ic) {
        this.ic = ic;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id;
    }

    public String getLect_id() {
        return lect_id;
    }

    public void setLect_id(String lect_id) {
        this.lect_id = lect_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    

  
}
