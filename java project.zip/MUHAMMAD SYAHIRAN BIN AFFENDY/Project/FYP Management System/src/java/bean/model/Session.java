/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean.model;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author SYAH
 */
public class Session {

    public Session() {
    }

    public boolean createSession(HttpServletRequest request, loginData ld) {
        try {
            HttpSession session = request.getSession();
            session.setAttribute("user", ld.getUser());
            session.setAttribute("role", ld.getRole());
            //setting session to expiry in 30 mins
            session.setMaxInactiveInterval(30 * 60);
            return true;
        } catch (Exception ex) {
            destroySession(request);
            ex.getMessage();
            return false;
        }
    }

    public void destroySession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }

    public void isNull(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || !request.isRequestedSessionIdValid()) {
                request.getRequestDispatcher("logoutServlet").forward(request, response);
            } else {
                if (!session.getAttribute("role").equals("admin")) {
                    if (session.getAttribute("role").equals("student")) {
                        response.sendRedirect("stu_home");
                    } else if (session.getAttribute("role").equals("lecturer")) {
                        response.sendRedirect("lect_home");
                    } else {
                        request.getRequestDispatcher("logoutServlet").forward(request, response);
                    }
                }
            }
        } catch (IOException | ServletException ex) {
            try {
                request.getRequestDispatcher("logoutServlet").forward(request, response);
                Logger.getLogger(Session.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ServletException | IOException ex1) {
                Logger.getLogger(Session.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

    }
}
